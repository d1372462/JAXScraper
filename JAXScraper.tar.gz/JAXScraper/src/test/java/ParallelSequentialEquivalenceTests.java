import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import jaxScraper.Scraper;
import jaxScraper.evaluators.XSoupExtractor;

import java.util.LinkedList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Tests to ensure that results from parallel and sequential scraping is the same
 */
public class ParallelSequentialEquivalenceTests {

    // sequential results:
    private static List<String> elementsFoundSequential = new LinkedList<>();
    private static List<Exception> exceptionsCaughtSequential = new LinkedList<>();
    // parallel results:
    private static List<String> elementsFoundParallel = new LinkedList<>();
    private static List<Exception> exceptionsCaughtParallel = new LinkedList<>();

    /**
     * Setup test scenario
     */
    @BeforeAll
    public static void setup()
    {
        // sequential setup:
       new Scraper()
               .setMaxDepth(3)
               .setExceptionConsumer( (url,exception) -> exceptionsCaughtSequential.add(exception))
               .addExtractor(new XSoupExtractor("//a/text()") , (identifier, elements) -> elementsFoundSequential.addAll(elements))
               .addDoFollow(url -> url.endsWith("/"))
               .setUseParallel(false)
               .run("http://10.0.0.45/RAID6/");
        // parallel setup:
        new Scraper()
                .setMaxDepth(3)
                .setExceptionConsumer( (url,exception) -> exceptionsCaughtParallel.add(exception))
                .addExtractor(new XSoupExtractor("//a/text()") , (identifier, elements) -> elementsFoundParallel.addAll(elements))
                .addDoFollow(url -> url.endsWith("/"))
                .setUseParallel(true)
                .run("http://10.0.0.45/RAID6/");
    }

    /**
     * Tests for size equivalencies
     */
    @Test
    public void test_parallel_sequential_size_equal()
    {
        assertEquals(exceptionsCaughtSequential.size(), exceptionsCaughtParallel.size());
        assertEquals(elementsFoundSequential.size(), elementsFoundParallel.size());
    }

    /**
     * Checks that both sequential and parallel results contain the same elements (not considering order)
     * (size already tested)
     */
    @Test
    public void test_elements_equivalent()
    {
        elementsFoundSequential.stream().forEach(element -> assertTrue(elementsFoundParallel.contains(element)));
    }
}
