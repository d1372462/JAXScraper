package jaxScraper.factories;

import jaxScraper.interfaces.ElementIdentifierFactoryIF;
import jaxScraper.interfaces.ElementIdentifierIF;
import jaxScraper.models.BasicElementIdentifier;
import org.jsoup.nodes.Element;

/**
 * Converts a given node to an identifier object
 * @author Daniel S. Valland
 */
public class BasicIdentifierFactory implements ElementIdentifierFactoryIF {

    @Override
    public ElementIdentifierIF create(Element element) {
        return new BasicElementIdentifier(element.baseUri());
    }
}
