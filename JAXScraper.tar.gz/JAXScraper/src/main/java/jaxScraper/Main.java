package jaxScraper;

import jaxScraper.evaluators.XSoupExtractor;
import jaxScraper.outputAccumulators.ResultDictionary;

import java.util.*;

public class Main {

    private long timedTest(boolean useParallel)
    {
        ResultDictionary linkLabels = new ResultDictionary(); // create an accumulator to store results
        long startTime = System.nanoTime();
        // setup & run scraper using chaining
        new Scraper()
                .setExceptionConsumer( (url,exception) -> System.out.println(exception)) // set exception consumer
                .addExtractor(new XSoupExtractor("//a/text()"),linkLabels)
                .addDoFollow(url -> url.endsWith("/"))
                .setUseParallel(useParallel)
                .setMaxDepth(2)
                .run("http://vg.no");
        return  (System.nanoTime() - startTime) / 1000000; // divide by 1 mill to go from nano --> milliseconds
    }

    private long timedTest_sequential()
    {
        return timedTest(false);
    }

    private long timedTest_parallel()
    {
        return timedTest(true);
    }

    /**
     * Runs multiple sequential and parallel scrapes and computes basic stats
     */
    public void timeTesting(int passes, boolean useCalibrationRun)
    {
        List<Long> timesSequential = new LinkedList<>();
        List<Long> timesParallel = new LinkedList<>();
        if (useCalibrationRun)
        {
            // calibration-run runs and discards an initial pass
            timedTest_parallel();
            timedTest_sequential();
        }
        // run multiple scrapes:
        for(int i=0; i < passes; i++)
        {
            timesParallel.add(timedTest_parallel());
            timesSequential.add(timedTest_sequential());
        }
        // sequential stats:
        double sequentialMin = (double)timesSequential.stream().min(Comparator.naturalOrder()).get() / (double)1000;
        double sequentialMax = (double)timesSequential.stream().max(Comparator.naturalOrder()).get() / (double)1000;
        double sequentialAvg = timesSequential.stream().mapToDouble(time -> (double) time).average().getAsDouble() / (double)1000;
        // parallel stats:
        double parallelMin = (double)timesParallel.stream().min(Comparator.naturalOrder()).get() / (double)1000;
        double parallelMax = (double)timesParallel.stream().max(Comparator.naturalOrder()).get() / (double)1000;
        double parallelAvg = timesParallel.stream().mapToDouble(time -> (double) time).average().getAsDouble() / (double)1000;
        // print results:
        System.out.println(System.lineSeparator()+
                "---------- Sequential ("+passes+" runs): ----------");
        System.out.println("Min time: "+sequentialMin);
        System.out.println("Max time: "+sequentialMax);
        System.out.println("AVG time: "+sequentialAvg);

        System.out.println(System.lineSeparator()+
                "---------- Parallel ("+passes+" runs): ----------");
        System.out.println("Min time: "+parallelMin);
        System.out.println("Max time: "+parallelMax);
        System.out.println("AVG time: "+parallelAvg);
    }

    public static void main(String[] args)
    {
        new Main().timeTesting(10,true);
    }
}
