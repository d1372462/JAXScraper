package jaxScraper;

import org.apache.commons.io.FileUtils;
import jaxScraper.exceptions.MissingFileMapperException;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;

/**
 * @author Daniel S. Valland
 * Class for simple file-download capability.
 */
public class FileDownloader {
    private boolean useParallel;
    private int connectionTimeout;
    private int readTimeout;
    private Function<URL,File> fileMapper; // maps a given url to a given file
    private BiConsumer<String,Exception> exceptionConsumer; // consumer that will receive all exceptions encountered

    public FileDownloader()
    {
        this.connectionTimeout = 30000;  // 30 sec by default
        this.readTimeout = 30000; // 30 sec by default
        this.exceptionConsumer = (sourceUrl, exception) -> {}; // ignore exception by default
    }

    // SETTERS:

    /**
     * Determines to download in parallel or not
     * @param useParallel
     * @return this
     */
    public FileDownloader setUseParallel(boolean useParallel) {
        this.useParallel = useParallel;
        return this;
    }

    /**
     * Sets connection timeout limit for connections
     * @param connectionTimeout
     * @return this
     */
    public FileDownloader setConnectionTimeout(int connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
        return this;
    }

    /**
     * Sets read timeout limit while reading from source
     * @param readTimeout
     * @return this
     */
    public FileDownloader setReadTimeout(int readTimeout) {
        this.readTimeout = readTimeout;
        return this;
    }

    /**
     * Sets a function that will receive each url as parameter, and
     * return a destination file for that url
     * @param fileMapper
     * @return this
     */
    public FileDownloader setFileMapper(Function<URL, File> fileMapper) {
        this.fileMapper = fileMapper;
        return this;
    }

    /**
     * Sets a consumer that will receive each exception encountered while downloading
     * @param exceptionConsumer
     * @return this
     */
    public FileDownloader setExceptionConsumer(BiConsumer<String, Exception> exceptionConsumer) {
        this.exceptionConsumer = exceptionConsumer;
        return this;
    }

    // GETTERS:
    public boolean isUseParallel() {
        return useParallel;
    }

    public int getConnectionTimeout() {
        return connectionTimeout;
    }

    public int getReadTimeout() {
        return readTimeout;
    }

    public Function<URL, File> getFileMapper() {
        return fileMapper;
    }

    public BiConsumer<String, Exception> getExceptionConsumer() {
        return exceptionConsumer;
    }

    /**
     * Internal method - checks that fileMapper is present before download
     */
    private void checkFileMapperMissing()
    {
        if (fileMapper==null)
        {
            throw new MissingFileMapperException("File mapper missing");
        }
    }

    /**
     * Downloads a single url to file.  Destination file is determined by
     * the fileMapper function (which receives a URL as input, and outputs a destionation File)
     * @param url to download
     * @throws MissingFileMapperException
     */
    private void download(URL url) {
        // check file-mapper set:
        checkFileMapperMissing();
        // download file:
        try {
            FileUtils.copyURLToFile(url, fileMapper.apply(url));
        } catch (IOException exception) {
            // send exception to consumer
            exceptionConsumer.accept(url.toString(),exception);
        }
    }

    /**
     * Downloads a single url to file.
     * @param url to download
     * @throws MissingFileMapperException
     */
    public void download(String url) {
        // check file-mapper set:
        checkFileMapperMissing();
        try {
            download(new URL(url));
        } catch (MalformedURLException exception) {
            // send exception to consumer
            exceptionConsumer.accept(url,exception);
        }
    }

    /**
     * Downloads a list of urls to multiple files
     * @param  urls to download
     * @throws MissingFileMapperException
     */
    public void download(List<String> urls)
    {
        if (useParallel)
        {
            urls.stream()
                    .parallel()
                    .forEach(url -> download(url));
        }else{
            urls.stream()
                    .forEach(url -> download(url));
        }
    }

}
