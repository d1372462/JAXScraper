package jaxScraper.interfaces;

import java.io.IOException;

/**
 * Function that can throw an IOException
 * @param <T>
 * @param <R>
 * @author Daniel S. Valland
 */
@FunctionalInterface
public interface CheckedIOExceptionFunction<T, R> {
    R apply(T t) throws IOException;
}