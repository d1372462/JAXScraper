package jaxScraper.interfaces;

public interface DocumentIF {

}
