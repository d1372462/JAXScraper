package jaxScraper.interfaces;

/**
 * Represents an identifier for a given element
 * (such as url, label or object reference) that is stored along with output
 * as an identifier for the source-element to provide traceability.
 * @author Daniel S. Valland
 */
public interface ElementIdentifierIF {


}
