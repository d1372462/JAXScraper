package jaxScraper.models;

import jaxScraper.interfaces.ElementIdentifierIF;

/**
 * @author Daniel S. Valland
 */
public class BasicElementIdentifier implements ElementIdentifierIF {
    private String label;
    public BasicElementIdentifier(String label)
    {
        this.label=label;
    }

    @Override
    public String toString()
    {
        return label;
    }

    @Override
    public int hashCode()
    {
        return label.hashCode();
    }

    public boolean Equals(Object obj)
    {
        return hashCode() == obj.hashCode();
    }
}
