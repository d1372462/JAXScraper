package jaxScraper;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author Daniel S. Valland
 * Url utils class
 */
public class UrlUtils {
    public String buildAbsolute(String baseUrl,String url)
    {
        // check url already complete:
        if (url.startsWith("http://") || url.startsWith("https://"))
        {
            return url;
        }
        // else build complete:
        try {
            URL fullUrl = new URL(new URL(baseUrl), url);
            return fullUrl.toString();
        } catch (MalformedURLException e) {
        }
        return "";
    }
}
