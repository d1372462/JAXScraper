package jaxScraper.interfaces;

import org.jsoup.nodes.Element;

/**
 * Implemented by factory classes responsible for generating
 * identifier objects from elements
 * @author Daniel S. Valland
 */
public interface ElementIdentifierFactoryIF {
     ElementIdentifierIF create(Element element);
}
