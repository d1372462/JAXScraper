package jaxScraper;

import jaxScraper.models.DoFollowQuery;
import jaxScraper.models.ExtractorEntry;
import jaxScraper.models.URL;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import us.codecraft.xsoup.Xsoup;
import java.io.IOException;
import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import jaxScraper.interfaces.*;

/**
 * Scraper class
 * @author Daniel S. Valland
 */
public class Scraper {
    private int maxDepth=Integer.MAX_VALUE;
    private boolean dontRepeat;
    private UrlUtils urlUtils;
    private Set<String> hasVisited;
    private Queue<URL> frontier;
    private Queue<ExtractorEntry> extractors;
    private Queue<DoFollowQuery> doFollowQueries;
    private Queue<Consumer<Element>> consumers;
    private boolean useParallel;
    private boolean persistHasVisited;
    private Function<Connection,Connection> connectionMiddleware;
    private CheckedIOExceptionFunction<String,Element> elementSupplier;
    private BiConsumer<URL,Exception> exceptionConsumer; // consumer that will receive all exceptions encountered
    private Function<List<URL>,List<URL>> linksMiddleware;
    private Consumer<String> hasVisitedConsumer; // receives urls to be marked as visited (added to some collection for further reference)
    private Function<String,Boolean> hasVisitedChecker; // receives a url and determines if the url has already been visited

    public Scraper()
    {
        this.urlUtils=new UrlUtils();
        this.hasVisited=new HashSet<>();
        this.extractors=new LinkedList<>();
        this.doFollowQueries=new LinkedList<>();
        this.consumers= new LinkedList<>();
        this.connectionMiddleware = connection -> connection; // default: do nothing
        this.elementSupplier = urlStr -> connectionMiddleware.apply(Jsoup.connect(urlStr)).get(); // default element supplier
        this.linksMiddleware = links -> links; // default: do nothing
        this.exceptionConsumer = (sourceUrl, exception) -> {}; // ignore exception by default
        this.dontRepeat=true; // don't repeat by default to avoid infinite follow loops
        this.useParallel=false; // use sequential be default to preserve order
        this.persistHasVisited=true; // keep hasVisited across multiple runs by default
        this.hasVisitedChecker = url -> this.hasVisited.contains(url); // check contains in internal set by default
        this.hasVisitedConsumer = url -> {
            if (dontRepeat){
                this.hasVisited.add(url);
            }
        }; // add to hasVisited by default
    }

    // SETTERS:

    /**
     * Sets a function that will receive a url as input and determine if the url has already been visited
     * (checks contains in internal set by default)
     * @param hasVisitedChecker
     * @return this
     */
    public Scraper setHasVisitedChecker(Function<String, Boolean> hasVisitedChecker)
    {
        this.hasVisitedChecker = hasVisitedChecker;
        return this;
    }

    /**
     * Sets a consumer for has-visited. The consumer will receive all urls to be marked as visited
     * (stored in a set by default, to be used to avoid repeating already visited urls)
     * Can be used to out-source the storing of visited urls
     * @param hasVisitedConsumer
     * @return this
     */
    public Scraper setHasVisitedConsumer(Consumer<String> hasVisitedConsumer)
    {
        this.hasVisitedConsumer = hasVisitedConsumer;
        return this;
    }

    /**
     * Sets a function that will receive each url as input, and return the root element from that
     * url
     * @param elementSupplier
     * @return this
     */
    public Scraper setElementSupplier(CheckedIOExceptionFunction<String, Element> elementSupplier)
    {
        this.elementSupplier = elementSupplier;
        return this;
    }

    /**
     * Determines to run scraping in parallel or not
     * @param useParallel
     * @return this
     */
    public Scraper setUseParallel(boolean useParallel)
    {
        this.useParallel = useParallel;
        return this;
    }

    /**
     * Determines to persist/preserve already visited urls across multiple runs
     * @param persistHasVisited
     * @return this
     */
    public Scraper setPersistHasVisited(boolean persistHasVisited)
    {
        this.persistHasVisited = persistHasVisited;
        return this;
    }

    /**
     * Determines to repeat already visited urls or not
     * (set to true to avoid infinite loops in the case A --> B --> A)
     * @param dontRepeat
     * @return this
     */
    public Scraper setDontRepeat(boolean dontRepeat)
    {
        this.dontRepeat = dontRepeat;
        return this;
    }

    /**
     * Sets the maximum depth at which the scraper will follow links
     * @param maxDepth
     * @return this
     */
    public Scraper setMaxDepth(int maxDepth)
    {
        this.maxDepth = maxDepth;
        return this;
    }

    /**
     * Sets a consumer that will receive each exception encountered while scraping
     * in the form: (sourceUrl, exception) where sourceUrl is the url at which the
     * exception was encountered
     * @param exceptionConsumer
     * @return this
     */
    public Scraper setExceptionConsumer(BiConsumer<URL, Exception> exceptionConsumer)
    {
        this.exceptionConsumer = exceptionConsumer;
        return this;
    }

    /**
     * Receives a function that takes as parameter a Jsoup Connection instance, and returns the instance with
     * modifications.  Allows to manipulate the jsoup connection before it is used by the scraper
     * (ex: set userAgent, referrer etc...)
     * @param connectionMiddleware
     * @return this
     */
    public Scraper setConnectionMiddleware(Function<Connection, Connection> connectionMiddleware)
    {
        this.connectionMiddleware = connectionMiddleware;
        return this;
    }

    // GETTERS:


    public boolean isDontRepeat() {
        return dontRepeat;
    }

    public Set<String> getHasVisited() {
        return hasVisited;
    }

    public Consumer<String> getHasVisitedConsumer() {
        return hasVisitedConsumer;
    }

    public Function<String, Boolean> getHasVisitedChecker() {
        return hasVisitedChecker;
    }

    public CheckedIOExceptionFunction<String, Element> getElementSupplier()
    {
        return elementSupplier;
    }

    public boolean isUseParallel()
    {
        return useParallel;
    }
    public int getMaxDepth()
    {
        return maxDepth;
    }
    public boolean isPersistHasVisited()
    {
        return persistHasVisited;
    }
    public BiConsumer<URL, Exception> getExceptionConsumer()
    {
        return exceptionConsumer;
    }

    // PUBLIC METHODS / PUBLIC INTERFACE:
    /**
     * Proxy-method for run. Accepts array of urls, and runs each url
     * @param startUrls (array of urls)
     * @param maxDepth
     */
    public Scraper run(String[] startUrls, int maxDepth)
    {
        for(String url : startUrls)
        {
            run(url);
        }
        return this;
    }

     /**
     * Runs scraping either sequentially or in parallel depending on useParallel boolean
     * @param startUrl -  The url to start from
     */
    public Scraper run(String startUrl)
    {
        if (!persistHasVisited)
        {
            this.hasVisited=new HashSet<>(); // clear hasVisited
        }
        reInitializeFrontier(); // re-inistalize frontier
        if (useParallel)
        {
            runInParallel(startUrl);
        }else{
            runSequential(startUrl);
        }
        return this;
    }

     /**
     * Adds a consumer to the list of consumers. For each page visited, the root element is passed to each consumer
     * for processing (with side-effects)
     * @param consumer
     * @return this
     */
    public Scraper addPageConsumer(Consumer<Element> consumer)
    {
        this.consumers.add(consumer);
        return this;
    }

     /**
     * Sets a middleware method for page links.  For each page visited, the list of links to follow from that
     * page are passed to the function, which returns a new or same queue of links to be followed.
     * (Useful for example for sorting links, excluding, adding or modifying links)
     * @param linksMiddleware method
     * @return this
     */
    public Scraper setLinksMiddleware(Function<List<URL>, List<URL>> linksMiddleware)
    {
        this.linksMiddleware = linksMiddleware;
        return this;
    }

     /**
     * Adds an extractor (function) to the scraper instance. The extractor is an instance of a functional interface
     * that is responsible for converting the root element of each page visited to a list of string output to be accumulated
     * for the visited page.  (The root element of each page visited by the scraper instance will be passed through each extractor,
     * and the output of each extractor is accumulated by the corresponding accumulator)
     * @param extractor
     * @param resultConsumer
     */
    public Scraper addExtractor(Function<Element,List<String>> extractor, BiConsumer<String,List<String>> resultConsumer)
    {
        this.extractors.add(new ExtractorEntry(extractor,resultConsumer, qualified -> true));
        return this;
    }

    /**
     * @param extractor
     * @param resultConsumer
     * @param qualifier (Predicate to be evaluated for each extracted result to qualify for accumulation)
     */
    public Scraper addExtractor(Function<Element,List<String>> extractor,  Predicate<String> qualifier, BiConsumer<String,List<String>> resultConsumer)
    {
        this.extractors.add(new ExtractorEntry(extractor,resultConsumer,qualifier));
        return this;
    }

    /**
     * Adds a doFollow query to the queue of doFollow. Takes an XSOUP query and a predicate as params,
     * and follows all links resulting from the XSOUP query that satisfy the predicate
     * @param query
     * @param urlQualifier
     */
    public Scraper addDoFollow(String query, Predicate<String> urlQualifier)
    {
        this.doFollowQueries.add(new DoFollowQuery(query,urlQualifier)); // else use qualifier passed as param
        return this;
    }

    /**
     * Adds a doFollow query to the queue of doFollow. Takes an XSOUP query and a predicate as params,
     * and follows all links resulting from the XSOUP query
     * @param query
     */
    public Scraper addDoFollow(String query)
    {
        this.doFollowQueries.add(new DoFollowQuery(query,qualified -> true));
        return this;
    }

    /**
     * Adds a doFollow query to the queue of doFollow. Takes a predicate as param, and follows all links
     * that satisfy the given predicate
     * @param urlQualifier
     */
    public Scraper addDoFollow(Predicate<String> urlQualifier)
    {
        addDoFollow("//a/@href",urlQualifier);
        return this;
    }


    // INTERNAL METHODS:
    /**
     * Initializes and sets the frontier to a new list
     */
    private void reInitializeFrontier()
    {
        frontier = new LinkedList<>();
    }
    /**
     * Receives a base-url and an element, and extracts all
     * outgoing links from the given element
     * @param baseUrl
     * @param element
     * @return List of all urls
     */
    private List<String> extractUrls(String baseUrl, Element element)
    {
        List<String> urls = new LinkedList<>();
        doFollowQueries.stream().forEach(
                doFollowQuery ->
                        urls.addAll(
                        Xsoup.compile(doFollowQuery.getQuery()).evaluate(element).list().stream()
                                .map(link -> this.urlUtils.buildAbsolute(baseUrl,link.trim())) // extract link href value (and trim)
                                .filter(linkString -> linkString.trim().length()>0) // keep only links  who's length > 0
                                .distinct()
                                .filter(doFollowQuery.getUrlQualifierPredicate())
                                .collect(Collectors.toList()) // collect to list
                        ));
        return urls;
    }

    /**
     * Runs scraping sequentially
     * @param startUrl -  The url to start from
     */
    private void runSequential(String startUrl)
    {
        frontier.add(new URL(startUrl,1));
        // continue while frontier not empty -- Breadth first scrape:
        while(!frontier.isEmpty())
        {
            scrape(frontier.remove());
        }
    }

    /**
     * Runs scraping in parallel - WARNING: Does not guarantee order
     * @param startUrl -  The url to start from
     */
    private void runInParallel(String startUrl)
    {
        frontier.add(new URL(startUrl,1));
        // continue while frontier not empty -- Breadth first scrape:
        while(!frontier.isEmpty())
        {
            Queue<URL> currentBatch = frontier; // preserve pointer to current list of urls
            reInitializeFrontier(); // replace current pointer with new instance
            currentBatch.stream().parallel().forEach(url -> scrape(url)); // process current batch in parallel
        }
    }

    /**
     * Scrapes, starting from the given start url (inclusive)
     * @param url - Starting url
     */
    private void scrape(URL url)
    {
        try {
             Element body = elementSupplier.apply(url.getUrl());
             // pass root through each consumer:
             consumers.stream().forEach(consumer -> consumer.accept(body));
            // perform extraction and accumulate:
            extractors.stream().parallel().forEach(extractorEntry ->
                    extractorEntry.getResultConsumer().accept(
                            url.getUrl(), // supply identifier (use url as identifier for result-batch)
                            extractorEntry.getExtractor().apply(body).stream() // use extractor to extract results
                            .filter(extractorEntry.getQualifier()).collect(Collectors.toList()) // filter based on predicate
                    ) );
            // add to frontier:
            frontier.addAll(
                    linksMiddleware.apply(
                            extractUrls(url.getUrl(),body).stream()
                            .filter(urlStr -> !hasVisited.contains(urlStr))
                            .map(urlStr -> new URL(urlStr,url.getDepth() + 1))// extract url strings and convert to URL objects
                            .distinct()
                            .filter(urlObj -> urlObj.getDepth() <= maxDepth)
                            .collect(Collectors.toList())
                    )
            );
        } catch (IOException exception) {
            this.exceptionConsumer.accept(url, exception);
        }
            hasVisitedConsumer.accept(url.getUrl());
    }
}
