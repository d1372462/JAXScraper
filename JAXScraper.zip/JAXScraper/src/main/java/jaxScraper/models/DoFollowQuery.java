package jaxScraper.models;

import java.util.function.Predicate;

/**
 * Stores a do-follow xsoup query, along with an optional function
 * to filter each resulting url from the do-follow query
 * @author Daniel S. Valland
 */
public class DoFollowQuery {
    private String query;
    private Predicate<String> urlQualifierPredicate;
    public DoFollowQuery(String query,Predicate<String> urlQualifierPredicate)
    {
        this.query=query;
        this.urlQualifierPredicate=urlQualifierPredicate;
    }
    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public Predicate<String> getUrlQualifierPredicate() {
        return urlQualifierPredicate;
    }

    public void setUrlQualifierPredicate(Predicate<String> urlQualifierPredicate) {
        this.urlQualifierPredicate = urlQualifierPredicate;
    }
}
