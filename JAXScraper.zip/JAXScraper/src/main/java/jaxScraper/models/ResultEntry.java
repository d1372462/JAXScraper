package jaxScraper.models;

import jaxScraper.interfaces.DocumentIF;

public class ResultEntry {
    private DocumentIF originDocument;
    private String resultStr;

    public ResultEntry(DocumentIF originDocument, String resultStr)
    {
        this.originDocument=originDocument;
        this.resultStr=resultStr;
    }

    public DocumentIF getOriginDocument() {
        return originDocument;
    }

    public void setOriginDocument(DocumentIF originDocument) {
        this.originDocument = originDocument;
    }

    public String getResultStr() {
        return resultStr;
    }

    public void setResultStr(String resultStr) {
        this.resultStr = resultStr;
    }

}
