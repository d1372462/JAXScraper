package jaxScraper.outputAccumulators;

import com.google.gson.Gson;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;

/**
 * Result-dictionary for storing scrape-results
 * @author Daniel S. Valland
 */
public class ResultDictionary extends LinkedHashMap<String, List<String>> implements BiConsumer<String,List<String>> {
    @Override
    public void accept(String identifier, List<String> evaluationOutput) {
        this.put(identifier,evaluationOutput);
    }

    public String toJson()
    {
        return new Gson().toJson(this);
    }

    public Map<String,List<Element>> toElements(Parser parser)
    {
        LinkedHashMap<String,List<Element>> result = new LinkedHashMap<>();
        this.keySet().stream().
                forEach(key ->
                        result.put(key,this.get(key).stream()
                                .map(str ->
                                        (Element) Jsoup.parse(str, "", parser))
                        .collect(Collectors.toList())));
        return result;
    }
}
