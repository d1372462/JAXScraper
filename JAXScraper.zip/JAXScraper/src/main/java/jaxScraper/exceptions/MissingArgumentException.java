package jaxScraper.exceptions;

/**
 * @author Daniel S. Valland
 */
public class MissingArgumentException extends Exception {
    public MissingArgumentException(String message)
    {
        super(message);
    }
}
