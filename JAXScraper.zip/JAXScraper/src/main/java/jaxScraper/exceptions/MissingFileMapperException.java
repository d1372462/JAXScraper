package jaxScraper.exceptions;

/**
 * @author Daniel S. Valland
 */
public class MissingFileMapperException extends RuntimeException {
    public MissingFileMapperException(String message)
    {
        super(message);
    }
}
