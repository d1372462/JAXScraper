package us.codecraft.xsoup;

import org.jsoup.nodes.Element;

/**
 * @author code4crafter@gmail.com
 */
public interface XElement {

    String get();

    Element getElement();

}
