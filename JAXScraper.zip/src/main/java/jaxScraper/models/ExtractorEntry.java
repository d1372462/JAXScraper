package jaxScraper.models;

import org.jsoup.nodes.Element;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Represents an extractor entry in the scraper class
 * @author Daniel S. Valland
 */
public class ExtractorEntry {
    private Function<Element,List<String>> extractor;
    private Predicate<String> qualifier;
    private BiConsumer<String,List<String>> resultConsumer;
    public ExtractorEntry(Function<Element,List<String>> extractor, BiConsumer<String,List<String>> resultConsumer, Predicate<String> qualifier)
    {
        this.extractor=extractor;
        this.qualifier=qualifier;
        this.resultConsumer=resultConsumer;
    }

    public BiConsumer<String,List<String>> getResultConsumer() {
        return resultConsumer;
    }

    public void setResultConsumer(BiConsumer<String,List<String>> resultAccumulator) {
        this.resultConsumer = resultAccumulator;
    }

    public Function<Element,List<String>> getExtractor() {
        return extractor;
    }

    public void setExtractor(Function<Element,List<String>> extractor) {
        this.extractor = extractor;
    }

    public Predicate<String> getQualifier() {
        return qualifier;
    }

    public void setQualifier(Predicate<String> qualifier) {
        this.qualifier = qualifier;
    }
}
