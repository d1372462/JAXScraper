package jaxScraper.evaluators;

import org.jsoup.nodes.Element;
import us.codecraft.xsoup.Xsoup;

import java.util.List;
import java.util.function.Function;

/**
 * Evaluator supporting XSoup queries and passes the resulting output
 * to the given result accumulator
 * @author Daniel S. Valland
 */
public class XSoupExtractor implements Function<Element,List<String>> {
    private String query;
    public XSoupExtractor(String query)
    {
        this.query=query;
    }


    @Override
    public List<String> apply(Element sourceElement) {
        return Xsoup.compile(query).evaluate(sourceElement).list();
    }
}
